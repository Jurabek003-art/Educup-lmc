// Backend service — keyingi bosqichda Supabase ulanadi.
