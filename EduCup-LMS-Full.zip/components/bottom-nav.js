// EduCup reusable component
