EduCup rasmlari shu yerga.
