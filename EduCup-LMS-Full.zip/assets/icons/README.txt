EduCup iconlari shu yerga.
