const content=document.querySelector('#content'),title=document.querySelector('#title');
const lessons=[['09:00','German B1','4-xona'],['11:00','IELTS','2-xona'],['14:00','English B2','5-xona'],['18:00','German A2','3-xona']];
const dashboard=()=>`<div class="hero"><h2>Assalomu alaykum 👋</h2><p>EduCup o‘quv markazining bugungi holati.</p></div>
<div class="stats">${[['Talabalar','1 284'],['Guruhlar','42'],['O‘qituvchilar','38'],['Davomat','92%']].map(x=>`<div class="card"><div class="label">${x[0]}</div><div class="number">${x[1]}</div><div class="up">↗ Faol ko‘rsatkich</div></div>`).join('')}</div>
<div class="grid"><div class="card"><h3>Oylik statistika</h3><div class="bars">${[42,55,48,67,61,79,72,88,80,94].map(v=>`<div class="bar" style="height:${v}%"></div>`).join('')}</div></div>
<div class="card"><h3>Bugungi darslar</h3>${lessons.map(x=>`<div class="row"><div><b>${x[0]} · ${x[1]}</b><small>${x[2]}</small></div><span class="badge">Faol</span></div>`).join('')}</div></div>`;
const generic=n=>`<div class="hero"><h2>${n}</h2><p>EduCup ${n.toLowerCase()} moduli.</p></div><div class="stats"><div class="card"><div class="label">HOLAT</div><div class="number">Faol</div><div class="up">✓ Modul ishlayapti</div></div><div class="card"><div class="label">KEYINGI BOSQICH</div><div class="number">DB</div><div class="up">Supabase ulanadi</div></div></div>`;
function render(v){let name={dashboard:'Dashboard',groups:'Guruhlar',attendance:'Davomat',payments:"To‘lovlar"}[v]||'Dashboard';title.textContent=name;content.innerHTML=v==='dashboard'?dashboard():generic(name)}
document.addEventListener('click',e=>{let b=e.target.closest('[data-view]');if(b){render(b.dataset.view);document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.view===b.dataset.view))}})
document.querySelector('#theme').onclick=()=>{let d=document.documentElement;let dark=d.dataset.theme==='dark';d.dataset.theme=dark?'light':'dark';localStorage.setItem('educup-theme',d.dataset.theme)}
document.documentElement.dataset.theme=localStorage.getItem('educup-theme')||'light';
if(window.Telegram?.WebApp){Telegram.WebApp.ready();Telegram.WebApp.expand()}
render('dashboard');
