# EduCup LMS

GitHub Pages uchun tayyor frontend.

## MUHIM
ZIPni ochgandan keyin `educup-lms` papkasining ichidagi fayllarni GitHub repository ROOT qismiga yuklang.

To‘g‘ri:
- index.html
- assets/
- pages/
- README.md

`index.html` hech qanday ichki papkaga kirmasligi kerak.

## Pages
- Asosiy: /index.html
- Admin: /pages/admin/index.html
- Teacher: /pages/teacher/index.html
- Student: /pages/student/index.html
